import sys
p = "services/api/src/socrat/assistant/service.py"
s = open(p, newline="").read()
nl = "\r\n" if "\r\n" in s else "\n"
s = s.replace("\r\n", "\n")

def sub(a, b, count=1):
    global s
    if s.count(a) < count:
        sys.exit(f"missing: {a[:80]!r}")
    s = s.replace(a, b, count)

sub('''def validate_scope(scope: str) -> str:
    if not _SCOPE.match(scope):
        raise HTTPException(422, "invalid_scope")
    return scope


def thread_for(db: Session, user_id: str, scope: str) -> AssistantThread:
    thread = db.scalar(''', '''def validate_scope(scope: str) -> str:
    if not _SCOPE.match(scope):
        raise HTTPException(422, "invalid_scope")
    return scope


# "general" and "plan" chats are kept per course: "general@<course id>". Without this, a
# learner who pauses a Kannada course and opens a math course would hand the math tutor the
# Kannada conversation. Problem and concept scopes already name their course.
COURSE = "@"
COURSE_SCOPES = {"general", "plan"}


def stored_scope(db: Session, user_id: str, scope: str) -> str:
    """The key a chat is stored under for the learner's active course."""
    scope = validate_scope(scope)
    if scope not in COURSE_SCOPES:
        return scope
    enrollment = learn.active_enrollment(db, user_id)
    return f"{scope}{COURSE}{enrollment.course_id}" if enrollment else scope


def public_scope(stored: str) -> str:
    """The scope a client knows, without the course or archive suffix."""
    return stored.split(ARCHIVED)[0].split(COURSE)[0]


def thread_for(db: Session, user_id: str, scope: str) -> AssistantThread:
    scope = stored_scope(db, user_id, scope)
    thread = db.scalar(''')

# thread_view
sub('''def thread_view(db: Session, user_id: str, scope: str) -> dict:
    scope = validate_scope(scope)
    thread = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user_id, AssistantThread.scope == scope
        )
    )
    if thread is None:
        return {
            "scope": scope,''', '''def thread_view(db: Session, user_id: str, scope: str) -> dict:
    scope = validate_scope(scope)
    key = stored_scope(db, user_id, scope)
    thread = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user_id, AssistantThread.scope == key
        )
    )
    if thread is None:
        return {
            "scope": scope,''')

# _owned_thread: also refuse another course's general/plan chat
sub('''        or not _SCOPE.match(thread.scope.split(ARCHIVED)[0])
    ):
        raise HTTPException(404, "not_found")
    return thread''', '''        or not _SCOPE.match(public_scope(thread.scope))
        # another course's general or plan chat stays with that course
        or thread.scope.split(ARCHIVED)[0] != stored_scope(db, user_id, public_scope(thread.scope))
    ):
        raise HTTPException(404, "not_found")
    return thread''')

# new_chat
sub('''    scope = validate_scope(scope)
    current = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user_id, AssistantThread.scope == scope
        )
    )
    if current is None or not _has_messages(db, current):
        return {"scope": scope, "archived": None}
    current.scope = f"{scope}{ARCHIVED}{current.id}"
    db.flush()
    carried = {k: v for k, v in current.ladder.items() if k != "engine"}
    db.add(
        AssistantThread(
            user_id=user_id, scope=scope, ladder=carried, created_at=now, updated_at=now
        )
    )
    db.flush()
    return {"scope": scope, "archived": current.id}''', '''    scope = validate_scope(scope)
    key = stored_scope(db, user_id, scope)
    current = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user_id, AssistantThread.scope == key
        )
    )
    if current is None or not _has_messages(db, current):
        return {"scope": scope, "archived": None}
    current.scope = f"{key}{ARCHIVED}{current.id}"
    db.flush()
    carried = {k: v for k, v in current.ladder.items() if k != "engine"}
    db.add(
        AssistantThread(user_id=user_id, scope=key, ladder=carried, created_at=now, updated_at=now)
    )
    db.flush()
    return {"scope": scope, "archived": current.id}''')

# list_chats
sub('''    scope = validate_scope(scope)
    threads = list(
        db.scalars(
            select(AssistantThread)
            .where(
                AssistantThread.user_id == user_id,
                (AssistantThread.scope == scope)
                | AssistantThread.scope.startswith(f"{scope}{ARCHIVED}", autoescape=True),
            )
            # The current chat first, then the newest archived ones.
            .order_by((AssistantThread.scope == scope).desc(), AssistantThread.updated_at.desc())''', '''    scope = validate_scope(scope)
    key = stored_scope(db, user_id, scope)
    threads = list(
        db.scalars(
            select(AssistantThread)
            .where(
                AssistantThread.user_id == user_id,
                (AssistantThread.scope == key)
                | AssistantThread.scope.startswith(f"{key}{ARCHIVED}", autoescape=True),
            )
            # The current chat first, then the newest archived ones.
            .order_by((AssistantThread.scope == key).desc(), AssistantThread.updated_at.desc())''')
sub('''                "current": thread.scope == scope,''', '''                "current": thread.scope == key,''')

# chat_view
sub('''    thread = _owned_thread(db, user_id, thread_id)
    base = thread.scope.split(ARCHIVED)[0]
    view = (
        thread_view(db, user_id, base)
        if thread.scope == base
        else {
            "scope": base,''', '''    thread = _owned_thread(db, user_id, thread_id)
    base = thread.scope.split(ARCHIVED)[0]
    view = (
        thread_view(db, user_id, public_scope(base))
        if thread.scope == base
        else {
            "scope": public_scope(base),''')

# resume_chat returns
sub('''    if thread.scope == base:
        return {"scope": base, "thread_id": thread.id}''', '''    if thread.scope == base:
        return {"scope": public_scope(base), "thread_id": thread.id}''')
sub('''    thread.updated_at = now
    db.flush()
    return {"scope": base, "thread_id": thread.id}''', '''    thread.updated_at = now
    db.flush()
    return {"scope": public_scope(base), "thread_id": thread.id}''')

# context_view
sub('''    sections = learner_sections(db, catalog, user, enrollment, now)
    thread = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user.id, AssistantThread.scope == scope
        )
    )
    state = engine.State.from_dict''', '''    sections = learner_sections(db, catalog, user, enrollment, now)
    key = stored_scope(db, user.id, scope)
    thread = db.scalar(
        select(AssistantThread).where(
            AssistantThread.user_id == user.id, AssistantThread.scope == key
        )
    )
    state = engine.State.from_dict''')

open(p, "w", newline="").write(s.replace("\n", nl))
print("ok")
