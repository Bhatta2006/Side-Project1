Everything produced in the 2026-11-04/05 Claude Code session, except the
browser profile (cookies, cache) and the downloaded REA package (npm: rea-agents@6.8.0).
scratchpad/: scripts, probes, patches, screenshots, network captures, REA capture and exported scripts, logs.
test-runs/: output of the background test runs (full suites and subsets).
Contains the account email/ids and Wondering's JavaScript: keep private.
