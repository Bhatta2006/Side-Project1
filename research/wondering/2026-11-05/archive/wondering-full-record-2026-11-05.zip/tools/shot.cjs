const { chromium } = require('playwright');
const out = process.argv[2];
const shape = { studio: 'reading', loop: 'read-reflect', evidence: ['quiz', 'explanation'], tools: [], label: 'Math Quest', name: 'Math Quest' };
const features = { code: false, library: false, companies: false, codeforces: false, drills: true };
const profile = { id: 'u', admin: false, display_name: 'Demo Learner', birth_year: 2018, timezone: 'UTC', csrf_token: 'x', onboarded: true, tour_seen: true,
  enrollment: { id: 'e', course: 'kids-math', language: 'python', status: 'active', minutes_per_day: 30, weekdays: [0,1,2,3,4,5,6], goal: {}, level: 'start', shape, features } };
const overview = { course: 'Math Adventures for Kids', per_day: 12, concepts: [
  { concept: 'kids-math:counting', title: 'Counting to 20', locked: false },
  { concept: 'kids-math:adding', title: 'Adding small numbers', locked: false },
  { concept: 'kids-math:shapes', title: 'Shapes around us', locked: true }],
  sets: [{ id: 'abc123def', concept: 'kids-math:counting', title: 'Counting to 20', created_at: 1, questions: 5, answered: 5, correct: 4 }] };
const set = { id: 'set123456', concept: 'kids-math:adding', title: 'Adding small numbers', created_at: 1, questions: 3, answered: 1, correct: 1, source: 'model', items: [
  { index: 0, kind: 'choice', prompt: 'Mia has 2 apples and finds 1 more. How many apples now?', options: ['2', '3', '4'], hint: 'Count on from 2.', given: '3', correct: true, expected: '3', explanation: '2 and 1 more makes 3.' },
  { index: 1, kind: 'choice', prompt: 'A frog hops 3 lily pads, then 2 more. How many hops?', options: ['4', '5', '6'], hint: 'Start at 3 and count 2 more.' },
  { index: 2, kind: 'number', prompt: 'What is 4 + 4 stars?', options: [], hint: '' }] };
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1 });
  await page.addInitScript(() => localStorage.setItem('socrat:tour-seen', '1'));
  const playing = { on: false };
  await page.route('**/api/v1/**', route => {
    const u = new URL(route.request().url()); const p = u.pathname;
    const json = b => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(b) });
    if (p.endsWith('/auth/status')) return json({ profile });
    if (p.endsWith('/features')) return json({ dev_login: true, demo_mode: false });
    if (p.endsWith('/drills') && route.request().method() === 'GET') return json(overview);
    if (p.endsWith('/drills') && route.request().method() === 'POST') return json(set);
    if (p.includes('/drills/')) return json(set);
    return route.fulfill({ status: 404, contentType: 'application/json', body: JSON.stringify({ error: { code: 'not_found' } }) });
  });
  await page.goto('http://127.0.0.1:3000/studio', { waitUntil: 'networkidle', timeout: 240000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: `${out}/studio.png`, fullPage: true });
  await page.getByRole('button', { name: /Start practising/ }).click();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${out}/play.png`, fullPage: true });
  await page.goto('http://127.0.0.1:3000/companies', { waitUntil: 'networkidle', timeout: 240000 });
  await page.waitForTimeout(2500);
  console.log('companies redirected to', page.url());
  const nav = await page.locator('nav[aria-label="Main"]').first().innerText();
  console.log('nav:', nav.replace(/\n+/g, ' | '));
  await page.goto('http://127.0.0.1:3000/settings', { waitUntil: 'networkidle', timeout: 240000 });
  await page.waitForTimeout(1500);
  console.log('settings has Codeforces:', await page.getByText('Codeforces').count(), 'language select:', await page.locator('#settings-language').count());
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
