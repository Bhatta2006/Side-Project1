const { chromium } = require('playwright');
const out = process.argv[2];
const shape = { studio: 'reading', loop: 'read-reflect', evidence: ['quiz'], tools: [], label: 'Math Quest', name: 'Math Quest' };
const features = { code: false, library: false, companies: false, codeforces: false, drills: true };
const profile = { id: 'u', admin: false, display_name: 'Demo Learner', birth_year: 2016, timezone: 'UTC', csrf_token: 'x', onboarded: true, tour_seen: true,
  enrollment: { id: 'e', course: 'kids-math', language: 'python', status: 'active', minutes_per_day: 30, weekdays: [0,1,2,3,4,5,6], goal: {}, level: 'start', shape, features } };
const overview = { course: 'Math Adventures', per_day: 12, concepts: [{ concept: 'kids-math:fractions', title: 'Fractions', locked: false }], sets: [] };
const base = { id: 'set123456', concept: 'kids-math:fractions', title: 'Fractions', created_at: 1, questions: 2, answered: 0, correct: 0, source: 'model' };
const items = [
  { index: 0, kind: 'order', prompt: 'Put the steps of adding fractions in order.', options: ['Add the numerators', 'Find a common denominator', 'Rewrite each fraction'], hint: 'What must match first?' },
  { index: 1, kind: 'match', prompt: 'Match each fraction to its decimal.', lefts: ['1/2', '1/4', '3/4'], options: ['0.75', '0.5', '0.25'], hint: '' },
];
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 390, height: 900 }, deviceScaleFactor: 1 });
  await page.addInitScript(() => localStorage.setItem('socrat:tour-seen', '1'));
  const sent = [];
  let state = { ...base, items };
  await page.route('**/api/v1/**', route => {
    const req = route.request(); const p = new URL(req.url()).pathname;
    const json = b => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(b) });
    if (p.endsWith('/auth/status')) return json({ profile });
    if (p.endsWith('/features')) return json({ dev_login: true });
    if (p.endsWith('/drills') && req.method() === 'GET') return json(overview);
    if (p.endsWith('/drills') && req.method() === 'POST') return json(state);
    if (p.endsWith('/answers')) {
      const body = JSON.parse(req.postData()); sent.push(body);
      const items2 = state.items.map(q => q.index === body.question ? { ...q, given: body.answer, correct: false, expected: 'the key', explanation: 'Because.' } : q);
      state = { ...state, items: items2, answered: state.answered + 1 };
      return json({ correct: false, expected: 'the key', explanation: 'Because.', set: state });
    }
    return route.fulfill({ status: 404, contentType: 'application/json', body: JSON.stringify({ error: { code: 'not_found' } }) });
  });
  await page.goto('http://127.0.0.1:3000/studio', { waitUntil: 'networkidle', timeout: 240000 });
  await page.getByRole('button', { name: /Start practising/ }).click();
  await page.getByRole('list', { name: 'Steps, in your order' }).waitFor();
  // Move "Add the numerators" (first) down once: [1,0,2]
  await page.getByRole('button', { name: 'Move "Add the numerators" down' }).click();
  await page.screenshot({ path: `${out}/order.png`, fullPage: true });
  const upDisabled = await page.getByRole('button', { name: /Move "Find a common denominator" up/ }).isDisabled();
  console.log('top item up-button disabled:', upDisabled);
  await page.getByRole('button', { name: 'Check my order' }).click();
  await page.getByRole('button', { name: /Next question/ }).click();
  // Match: Check is disabled until every left has a different partner.
  const check = page.getByRole('button', { name: 'Check my matches' });
  console.log('match check disabled at start:', await check.isDisabled());
  const sel = i => page.getByLabel(`Partner for ${['1/2','1/4','3/4'][i]}`);
  await sel(0).selectOption('1'); await sel(1).selectOption('1'); await sel(2).selectOption('0');
  console.log('disabled with a duplicate partner:', await check.isDisabled(), '| note:', await page.getByText('Each partner can be used once.').count());
  await sel(1).selectOption('2');
  await page.screenshot({ path: `${out}/match.png`, fullPage: true });
  console.log('enabled when complete and distinct:', !(await check.isDisabled()));
  await check.click();
  await page.waitForTimeout(800);
  console.log('answers sent:', JSON.stringify(sent));
  console.log('horizontal overflow px:', await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth));
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
