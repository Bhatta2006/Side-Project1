const { chromium } = require('playwright');
const out = process.argv[2];
const profile = { id: 'u', admin: false, display_name: 'Demo Learner', birth_year: 1995, timezone: 'UTC', csrf_token: 'x', onboarded: true, tour_seen: true,
  enrollment: { id: 'e', course: 'zero', language: 'python', status: 'active', minutes_per_day: 30, weekdays: [0,1,2,3,4,5,6], goal: {}, level: 'brand-new',
    shape: { studio: 'code', loop: 'solve', evidence: ['tests'], tools: ['editor'], name: 'Practice' }, features: { code: true, library: true, companies: false, codeforces: false, drills: true } } };
const options = { subjects: [{ id: 's1', label: 'Fractions for kids', group: 'maths' }], groups: [{ id: 'time', title: 'Time', choices: [{ id: 'time-5', label: '5 minutes a day' }] }] };
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 390, height: 900 }, deviceScaleFactor: 1 });
  await page.addInitScript(() => localStorage.setItem('socrat:tour-seen', '1'));
  let posted = null;
  await page.route('**/api/v1/**', route => {
    const p = new URL(route.request().url()).pathname;
    const json = b => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(b) });
    if (p.endsWith('/auth/status')) return json({ profile });
    if (p.endsWith('/features')) return json({ dev_login: true });
    if (p.endsWith('/learning-requests/options')) return json(options);
    if (p.endsWith('/enrollments')) return json({ items: [] });
    if (p.endsWith('/learning-requests') && route.request().method() === 'POST') { posted = JSON.parse(route.request().postData()); return json({ id: 'r1', text: posted.text, status: 'parsed', source: 'rules', intent: { subject: 'Photosynthesis', goal: 'Explain it' }, material_chars: (posted.material || '').length, course_id: null, blueprint: null, job: null }); }
    return route.fulfill({ status: 404, contentType: 'application/json', body: JSON.stringify({ error: { code: 'not_found' } }) });
  });
  await page.goto('http://127.0.0.1:3000/new', { waitUntil: 'networkidle', timeout: 240000 });
  await page.waitForTimeout(1500);
  await page.locator('#subject').fill('Make a course from my biology notes');
  await page.getByText('Build it from your own notes (optional)').click();
  await page.locator('#material').fill('Photosynthesis turns light, water and CO2 into glucose and oxygen.');
  await page.screenshot({ path: `${out}/new-notes.png`, fullPage: true });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  console.log('horizontal overflow px:', overflow);
  await page.getByRole('button', { name: /make|build|create/i }).last().click();
  await page.waitForTimeout(1500);
  console.log('posted body:', JSON.stringify(posted));
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
