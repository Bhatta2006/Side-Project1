from test_learner_api import client, login  # noqa: F401
from test_learning_requests import URL, on  # noqa: F401
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from socrat.models import LearningRequest

def test_probe(on):  # noqa: F811
    ada = login(on, subject="ada")
    assert on.post(URL, json={"text": "teach me algebra"}, headers=ada).status_code == 200
    r = on.delete("/api/v1/me", headers=ada)
    print("PROBE delete", r.status_code, r.text[:200])
    with Session(on.app.state.engine) as db:
        print("PROBE rows left", db.scalar(select(func.count()).select_from(LearningRequest)))
