import{l as a}from"./index-BRt2xgxC.js";(function(){try{var e=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};e.SENTRY_RELEASE={id:"5b26efe4c13f392741aa3e5cb052489de43cfc06"};var d=new e.Error().stack;d&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[d]="46b242ea-e8de-43e6-81c5-3ead7e83ad82",e._sentryDebugIdIdentifier="sentry-dbid-46b242ea-e8de-43e6-81c5-3ead7e83ad82")}catch{}})();/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]],o=a("mail",t);export{o as M};
