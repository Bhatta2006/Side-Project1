import{l as d}from"./index-BRt2xgxC.js";(function(){try{var e=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};e.SENTRY_RELEASE={id:"5b26efe4c13f392741aa3e5cb052489de43cfc06"};var n=new e.Error().stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="55915393-5c85-4b9a-970a-2cb945b8c108",e._sentryDebugIdIdentifier="sentry-dbid-55915393-5c85-4b9a-970a-2cb945b8c108")}catch{}})();/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"M5 12h14",key:"1ays0h"}]],t=d("minus",c);export{t as M};
