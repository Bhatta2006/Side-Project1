Unredacted record of the Wondering study, 2026-11-05. Contains the account email and ids,
and Wondering's own JavaScript as served to the browser. Keep private; do not commit to a repository.
The redacted, documented version is research/wondering/2026-11-05 in the Socrat repo.
